<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us | TeaToYou</title>

    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body, html {
            height: 100%;
            margin: 0;
            font-family: 'Poppins', sans-serif;
            background-color: #f5f5dc;
            color: #5d4037;
        }

        .sidenav {
            height: 100%;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            background: rgba(245, 222, 179, 0.95);
            padding-top: 30px;
            padding-left: 20px;
            backdrop-filter: blur(5px);
            box-shadow: 2px 0 5px rgba(0,0,0,0.2);
        }
        .sidenav a {
            display: block;
            color: #5d4037;
            font-size: 1.3rem;
            margin: 20px 0;
            text-decoration: none;
            font-weight: bold;
        }
        .sidenav a:hover {
            color: #ff7f50;
        }

        .main-content {
            margin-left: 270px;
            padding: 50px;
        }

        .about-section {
            background: rgba(255, 250, 240, 0.9);
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.1);
            text-align: center;
            margin-top: 50px;
        }

        .about-section h1 {
            font-size: 3rem;
            margin-bottom: 30px;
        }

        .about-content {
            font-size: 1.2rem;
            line-height: 1.8;
            text-align: justify;
        }

        .button-primary {
            display: inline-block;
            margin-top: 30px;
            background-color: #f5deb3;
            color: #5d4037;
            font-size: 1.1rem;
            padding: 10px 30px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            text-decoration: none;
        }

        .button-primary:hover {
            background-color: #5d4037;
            color: #fff;
        }

        .footer {
            text-align: center;
            padding: 20px 0;
            background: rgba(245, 222, 179, 0.8);
            color: #5d4037;
            margin-top: 50px;
            backdrop-filter: blur(8px);
            box-shadow: 0 -2px 5px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>

    <!-- Side Navigation -->
    <div class="sidenav">
        <h2>TeaToYou</h2>
        <a href="homepage.php">Home</a>
        <a href="menu.php">Menu</a>
        <a href="cart.php">Cart</a>
        <a href="about.php">About Us</a>
        <a href="contact.php">Contact</a>
        <a href="login.php">Log In</a>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="about-section">
            <h1>About TeaToYou</h1>
            <div class="about-content">
                <p>Welcome to <strong>TeaToYou</strong>! We are a passionate team of milk tea lovers, committed to bringing you the best milk tea experience, all from the comfort of your home.</p>
                <p>Founded in 2025, TeaToYou is dedicated to providing fresh, high-quality milk tea drinks and snacks delivered directly to your door. Our menu includes a wide range of traditional and innovative milk tea flavors, carefully crafted with premium ingredients to give you that perfect refreshing taste every time.</p>
                <p>We take pride in our customer service and strive to make every sip a memorable one. Whether you're a classic milk tea lover or a fan of fruity flavors, we've got something for everyone. Join the TeaToYou family and experience the joy of milk tea delivered straight to you!</p>
            </div>
            <!-- Back to Homepage Button -->
            <a href="homepage.php" class="button-primary">Back to Homepage</a>
        </div>
    </div>

    <!-- Footer -->
    <div class="footer">
        <p>&copy; 2025 TeaToYou. Wok'd with Love, Served for Juan. 🧋</p>
    </div>

</body>
</html>
