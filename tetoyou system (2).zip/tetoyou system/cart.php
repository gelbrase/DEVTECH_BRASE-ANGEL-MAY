<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>TeaToYou | Cart</title>
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet"/>

  <style>
    body {
      background-color: #f5f5dc;
      font-family: 'Arial', sans-serif;
      color: #5d4037;
    }
    .container {
      margin-top: 50px;
    }
    .card {
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
      background-color: #fff8e1;
      margin-bottom: 20px;
    }
    .cart-item {
      padding: 15px;
      border-bottom: 1px solid #e0e0e0;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .cart-item:last-child {
      border-bottom: none;
    }
    .button-remove {
      background-color: #8b5a2b;
      color: white;
      border: none;
      padding: 6px 12px;
      border-radius: 5px;
      cursor: pointer;
      font-size: 14px;
    }
    .button-remove:hover {
      background-color: #cc0000;
    }
    .quantity-input {
      width: 50px;
      padding: 5px;
      text-align: center;
    }
    .checkout-btn {
      background-color: #28a745;
      color: white;
      padding: 12px 20px;
      border-radius: 5px;
      border: none;
      width: 100%;
      font-size: 18px;
      margin-top: 15px;
    }
    .checkout-btn:hover {
      background-color: #218838;
    }
    h1 {
      margin-bottom: 30px;
    }
    .empty-cart {
      text-align: center;
      padding: 20px;
      color: #888;
    }
    .back-to-menu {
      margin-top: 20px;
      text-align: center;
    }
    .back-to-menu a {
      color: #5d4037;
      font-weight: bold;
      text-decoration: none;
    }
    .back-to-menu a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

<div class="container">
  <h1 class="text-center">TeaToYou Cart 🛒</h1>

  <div class="row justify-content-center">
    <div class="col-md-8">
      <div class="card p-3">
        <h3 class="text-center">Order Summary</h3>
        <div id="cart-items"></div>
        <h4 class="text-right mt-3">Total: ₱<span id="cart-total">0.00</span></h4>
        <button class="checkout-btn" id="checkout-btn" onclick="checkout()">Proceed to Checkout</button>
      </div>

      <div class="back-to-menu">
        <p><a href="menu.php">← Back to Menu</a></p>
      </div>
    </div>
  </div>
</div>

<script>
  function loadCart() {
    let cart = localStorage.getItem("cart") ? JSON.parse(localStorage.getItem("cart")) : [];
    let cartItems = document.getElementById("cart-items");
    let total = 0;
    cartItems.innerHTML = "";

    if (cart.length === 0) {
      cartItems.innerHTML = "<div class='empty-cart'>Your cart is empty.</div>";
      document.getElementById("checkout-btn").style.display = "none";
      document.getElementById("cart-total").innerText = "0.00";
      return;
    }

    cart.forEach((item, index) => {
      let itemTotal = item.price * item.quantity;
      total += itemTotal;

      cartItems.innerHTML += `
        <div class="cart-item">
          <span>${item.name} - ₱${item.price.toFixed(2)} x 
            <input type="number" class="quantity-input" value="${item.quantity}" min="1" 
            onchange="updateQuantity(${index}, this.value)">
          </span>
          <button class="button-remove" onclick="removeFromCart(${index})">Remove</button>
          <span>₱${itemTotal.toFixed(2)}</span>
        </div>
      `;
    });

    document.getElementById("cart-total").innerText = total.toFixed(2);
    document.getElementById("checkout-btn").style.display = "block";
  }

  function updateQuantity(index, newQuantity) {
    let cart = JSON.parse(localStorage.getItem("cart"));
    cart[index].quantity = parseInt(newQuantity);
    localStorage.setItem("cart", JSON.stringify(cart));
    loadCart();
  }

  function removeFromCart(index) {
    let cart = JSON.parse(localStorage.getItem("cart"));
    cart.splice(index, 1);
    localStorage.setItem("cart", JSON.stringify(cart));
    loadCart();
  }

  function checkout() {
    let cart = JSON.parse(localStorage.getItem("cart"));
    let total = parseFloat(document.getElementById("cart-total").innerText);

    if (cart.length === 0) {
      alert("Your cart is empty.");
      return;
    }

    let paymentOption = prompt(
      "Choose your payment method:\n1 - Pay Online via GCash\n2 - Pay Upon Pickup/Delivery (Cash)",
      "1"
    );

    if (paymentOption === "1") {
      alert("Redirecting to GCash via PayMongo...");
      // ✅ Replace this link with your real PayMongo GCash checkout link
      window.location.href = "https://paymongo.page.link/your-gcash-link";
    } else if (paymentOption === "2") {
      if (confirm("Are you sure you want to place this order and pay upon pickup/delivery?")) {
        alert("Thank you for your order! 🧋 Please prepare your payment.");
        localStorage.removeItem("cart");
        loadCart();
        window.location.href = "homepage.php";
      }
    } else {
      alert("Invalid option. Please try again.");
    }
  }

  window.onload = loadCart;
</script>

</body>
</html>
