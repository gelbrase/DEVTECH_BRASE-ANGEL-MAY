<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Contact Us | TeaToYou</title>

  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #f5f5dc;
      color: #5d4037;
      font-family: Arial, sans-serif;
    }
    .container {
      margin-top: 50px;
    }
    .contact-section h1 {
      text-align: center;
      margin-bottom: 30px;
    }
    .contact-content {
      font-size: 1.2rem;
      line-height: 1.6;
    }
    .contact-form input, .contact-form textarea {
      width: 100%;
      padding: 10px;
      margin: 10px 0;
      border: 1px solid #ddd;
      border-radius: 5px;
    }
    .contact-form button {
      background-color: #ffebcd;
      color: #5d4037;
      font-size: 1.2rem;
      padding: 10px 30px;
      border: none;
      cursor: pointer;
      border-radius: 5px;
    }
    .contact-form button:hover {
      background-color: #5d4037;
      color: #fff;
    }
    .footer {
      text-align: center;
      padding: 30px 0;
      color: #5d4037;
    }
  </style>
</head>
<body>

  <div class="container">
    <div class="contact-section">
      <h1>Contact Us</h1>
      <div class="contact-content">
        <p>If you have any questions, feedback, or suggestions, we'd love to hear from you! Feel free to reach out to us using the contact form below or through any of the following methods:</p>
        <ul>
          <li>Email: <a href="mailto:support@teatoyou.com">support@teatoyou.com</a></li>
          <li>Phone: +1 (234) 567-8901</li>
          <li>Location: 123 Tea Street, Milk Tea Town, Philippines</li>
        </ul>
      </div>

      <div class="contact-form">
        <h3>Send Us a Message</h3>
        <form onsubmit="return showThankYouMessage();">
          <input type="text" name="name" placeholder="Your Name" required>
          <input type="email" name="email" placeholder="Your Email" required>
          <textarea name="message" rows="5" placeholder="Your Message" required></textarea>
          <button type="submit">Send Message</button>
        </form>
      </div>
    </div>
  </div>

  <div class="footer">
    <p>&copy; 2025 TeaToYou. All rights reserved.</p>
  </div>

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

  <script>
    function showThankYouMessage() {
      alert("Thank you for contacting us!");
      window.location.href = "homepage.php"; // Redirect to your homepage
      return false; // prevent form from actually submitting
    }
  </script>

</body>
</html>
