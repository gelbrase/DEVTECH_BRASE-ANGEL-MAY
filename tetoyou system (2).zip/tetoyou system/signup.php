<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - TeaToYou</title>
    <style>
        /* Global Styles */
        body {
            font-family: 'Georgia', serif;
            font-size: 18px;
            background-color: #F5E8D7; /* Beige background */
            background-image: url('https://www.transparenttextures.com/patterns/food.png'); /* Adds subtle texture */
            color: #5A3931; /* Dark brown text */
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        /* Sign-Up Form Container */
        .form-container {
            background-color: #FFFFFF; /* White background for contrast */
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            padding: 30px;
            width: 90%;
            max-width: 500px;
            text-align: center;
        }

        h1 {
            font-size: 2.5em;
            color: #4A3221; /* Rich brown */
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        label {
            font-size: 1.1em;
            text-align: left;
            color: #6E4F39; /* Light brown */
        }

        input {
            padding: 10px 15px;
            font-size: 1em;
            border: 1px solid #C2A88C; /* Soft beige border */
            border-radius: 8px;
            outline: none;
            transition: border-color 0.3s ease;
        }

        input:focus {
            border-color: #C29872; /* Milk tea tone */
        }

        .btn {
            padding: 12px 20px;
            font-size: 1.2em;
            font-weight: bold;
            color: #FFFFFF;
            background-color: #C29872; /* Milk tea beige tone */
            border: none;
            border-radius: 25px;
            cursor: pointer;
            transition: all 0.3s ease-in-out;
        }

        .btn:hover {
            background-color: #D4B89F; /* Lighter beige */
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        }

        .back-link {
            margin-top: 20px;
            font-size: 1em;
            color: #6E4F39;
            text-decoration: none;
        }

        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h1>Create Your Account</h1>
        <form action="process_signup.php" method="POST">
            <label for="name">Name</label>
            <input type="text" id="name" name="name" placeholder="Enter your name" required>

            <label for="email">Email</label>
            <input type="email" id="email" name="email" placeholder="Enter your email" required>

            <label for="password">Password</label>
            <input type="password" id="password" name="password" placeholder="Create a password" required>

            <button type="submit" class="btn">Sign Up</button>
        </form>
        <a href="index.php" class="back-link">Back to Home</a>
    </div>
</body>
</html>
