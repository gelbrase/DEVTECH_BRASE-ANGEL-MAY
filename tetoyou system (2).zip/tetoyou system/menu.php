<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Custom CSS -->
    <style>
        body {
            background-color: #f5f5dc;
            color: #5d4037;
            font-family: 'Arial', sans-serif;
        }

        .sidenav {
            height: 100%;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            background: rgba(245, 222, 179, 0.95); /* Light creamy sidebar */
            padding-top: 30px;
            padding-left: 20px;
            backdrop-filter: blur(5px);
            box-shadow: 2px 0 5px rgba(0,0,0,0.2);
        }
        .sidenav a {
            display: block;
            color: #5d4037;
            font-size: 1.3rem;
            margin: 20px 0;
            text-decoration: none;
            font-weight: bold;
        }
        .sidenav a:hover {
            color: #ff7f50;
        }
        .main-content {
            margin-left: 250px;
            padding: 20px;
        }

        .menu-category {
            width: 80%;
            margin: auto;
            margin-bottom: 30px;
            text-align: center;
        }

        .drink-item {
            background-color: #fff8e1;
            border: 1px solid #e0e0e0;
            border-radius: 10px;
            overflow: hidden;
            width: 220px;
            height: 340px;
            text-align: center;
            padding: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s;
            margin: 15px;
            display: inline-block;
            vertical-align: top;
        }

        .drink-item:hover {
            transform: scale(1.05);
        }

        .drink-item img {
            width: 100%;
            height: 180px;
            object-fit: cover;
            border-radius: 8px;
        }

        .drink-name {
            font-size: 1.2em;
            font-weight: bold;
            color: #8b5a2b;
            margin-top: 10px;
            display: block;
        }

        .price {
            font-size: 1.1em;
            color: #4CAF50;
            margin-top: 5px;
            display: block;
        }

        .button-cart {
            background-color: #8b5a2b;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
            font-size: 0.9em;
            transition: background-color 0.3s;
        }

        .button-cart:hover {
            background-color: #6a4028;
        }

        .footer {
            text-align: center;
            padding: 20px;
            background-color: #d8c8b8;
            color: #5d4037;
            margin-top: 20px;
        }
    </style>
</head>
<body>

<!-- Side Navigation -->
<div class="sidenav">
    <h2>TeaToYou</h2>
    <a href="homepage.php">Home</a>
    <a href="menu.php">Menu</a>
    <a href="cart.php">Cart</a>
    <a href="about.php">About Us</a>
    <a href="contact.php">Contact</a>
    <a href="login.php">Log In</a>
</div>

<!-- Main Content -->
<div class="main-content">

    <h2 class="text-center">MILK TEA</h2>

    <div class="menu-category">
        <?php
        $milkTeaItems = [
            ["Okinawa", "images/okinawa_02.jpg", 60],
            ["Taro", "images/taro_96.png.jpg", 75],
            ["Wintermelon", "images/wintermelon1.jpg", 60],
            ["Cookies and Cream", "images/coockies and cream1.jpg", 60],
            ["Mango Cheesecake", "images/mango cheescake 1.jpg", 75],
            ["Matcha", "images/matcha1.jpg", 65],
            ["Red Velvet", "images/red velvet1.jpg", 70],
            ["Dark Choco", "images/dark choco1.jpg", 60],
            ["Hazelnut", "images/hazelnut 1.jpg", 70],
            ["Vanilla", "images/vanilla1.jpg", 70],
            ["Avocado", "images/avocado1.jpg", 70],
            ["Hokkaido", "images/hokkaido1.jpg", 70]
        ];

        foreach ($milkTeaItems as $item) {
            echo '<div class="drink-item">
                    <img src="'.$item[1].'" alt="'.$item[0].'">
                    <span class="drink-name">'.$item[0].'</span>
                    <span class="price">₱'.$item[2].'</span>
                    <button class="button-cart" onclick="addToCart(\''.$item[0].'\', '.$item[2].')">Add to Cart</button>
                  </div>';
        }
        ?>
    </div>

    <h2 class="text-center">FRUIT TEA</h2>

    <div class="menu-category">
        <?php
        $fruitTeaItems = [
            ["Strawberry", "images/strawberry2.jpg", 60],
            ["Blueberry", "images/blueberry2.jpg", 75],
            ["Green Apple", "images/greenapple2.jpg", 60],
            ["Passion Fruit", "images/passion2.jpg", 60],
            ["Peach", "images/peach2.jpg", 75],
            ["Lemon", "images/lemon2.jpg", 65],
            ["Watermelon", "images/watermelon2.jpg", 70],
            ["Grapes", "images/grapes2.jpg", 60]
        ];

        foreach ($fruitTeaItems as $item) {
            echo '<div class="drink-item">
                    <img src="'.$item[1].'" alt="'.$item[0].'">
                    <span class="drink-name">'.$item[0].'</span>
                    <span class="price">₱'.$item[2].'</span>
                    <button class="button-cart" onclick="addToCart(\''.$item[0].'\', '.$item[2].')">Add to Cart</button>
                  </div>';
        }
        ?>
    </div>

    <h3 class="text-center">SPECIALTY DRINKS</h3>

    <div class="menu-category">
        <?php
        $specialtyItems = [
            ["Oreo Cheesecake", "images/orea cheescake 3.jpg", 120],
            ["Choco Strawberry", "images/choco strawberry3.jpg", 135],
            ["Dirty Matcha", "images/dirty matcha.jpg", 130],
            ["Mango Cheesecake", "images/mangocheesecake 3.jpg", 110],
            ["Java Chip", "images/java chip 3.jpg", 115],
            ["Red Velvet Cream Cheese", "images/red cream cheese 3.jpg", 120],
            ["Mint Chocolate Cream", "images/mint chocolate 3.jpg", 100],
            ["Salted Caramel", "images/salted caramel 3.jpg", 110]
        ];

        foreach ($specialtyItems as $item) {
            echo '<div class="drink-item">
                    <img src="'.$item[1].'" alt="'.$item[0].'">
                    <span class="drink-name">'.$item[0].'</span>
                    <span class="price">₱'.$item[2].'</span>
                    <button class="button-cart" onclick="addToCart(\''.$item[0].'\', '.$item[2].')">Add to Cart</button>
                  </div>';
        }
        ?>
    </div>

</div>

<!-- Footer -->
<div class="footer">
    <p>&copy; 2025 TeaToYou. All rights reserved.</p>
</div>

<!-- JavaScript to handle Add to Cart -->
<script>
    function addToCart(name, price) {
        let cart = localStorage.getItem("cart") ? JSON.parse(localStorage.getItem("cart")) : [];
        cart.push({ name: name, price: price });
        localStorage.setItem("cart", JSON.stringify(cart));
        alert(name + " added to cart!");
    }
</script>

</body>
</html>
