<?php
// Start the session
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | TeaToYou</title>
    <style>

       body {
            font-family: Arial, sans-serif;
            background-color: #f5e6cc; /* Beige theme */
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
        }
        .login-container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
            width: 350px;
            text-align: center;
        }
        h2 {
            color: #8b5a2b; /* Milk-tea brown */
        }
        input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .btn {
            background-color: #8b5a2b;
            color: white;
            padding: 10px;
            border: none;
            width: 100%;
            border-radius: 5px;
            cursor: pointer;
        }

       
        .btn:hover {
            background-color: #6a4028;
        }
        .signup-link {
            margin-top: 15px;
            display: block;
            color: #8b5a2b;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Login</h2>
        <h2><img src="images/mtea.jpg" alt="Girl in a jacket"> <h2>
        <form action="process_login.php" method="POST">
            <input type="email" name="email" placeholder="Email Address" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit" class="btn">Login</button>
        </form>
        <a href="signup.php" class="signup-link">Don't have an account? 
            <br>Sign Up</br></a>
    </div>
</body>
</html>
