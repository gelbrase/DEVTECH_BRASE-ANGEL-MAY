<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TeaToYou | Home</title>

    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">

    <style>
        /* Beige background */
        body, html {
            height: 100%;
            margin: 0;
            font-family: 'Poppins', sans-serif;
            background-color: #f5f5dc; /* Solid beige background */
            color: #5d4037;
            overflow-x: hidden;
        }

        .sidenav {
            height: 100%;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            background: rgba(245, 222, 179, 0.95); /* Light creamy sidebar */
            padding-top: 30px;
            padding-left: 20px;
            backdrop-filter: blur(5px);
            box-shadow: 2px 0 5px rgba(0,0,0,0.2);
        }
        .sidenav a {
            display: block;
            color: #5d4037;
            font-size: 1.3rem;
            margin: 20px 0;
            text-decoration: none;
            font-weight: bold;
        }
        .sidenav a:hover {
            color: #ff7f50;
        }

        .main-content {
            margin-left: 270px;
            padding: 50px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .glass-card {
            background: rgba(255, 250, 240, 0.9);
            border-radius: 20px;
            padding: 40px;
            max-width: 800px;
            text-align: center;
            backdrop-filter: blur(10px);
            box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.2);
            margin-bottom: 50px;
        }

        .glass-card h1 {
            font-size: 3rem;
            margin-bottom: 20px;
            color: #5d4037;
        }

        .glass-card p {
            font-size: 1.2rem;
            margin-bottom: 20px;
            color: #5d4037;
        }

        .button-primary {
            background-color: #f5deb3; /* Beige button */
            color: #5d4037;
            font-size: 1.1rem;
            padding: 10px 30px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            text-decoration: none;
        }

        .button-primary:hover {
            background-color: #5d4037;
            color: #fff;
        }

        .features {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
            justify-content: center;
            margin-top: 40px;
        }

        .feature-box {
            background: rgba(255, 245, 230, 0.9);
            border-radius: 15px;
            padding: 20px;
            width: 250px;
            text-align: center;
            transition: transform 0.3s ease, background 0.3s ease;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }

        .feature-box:hover {
            transform: translateY(-10px);
            background: rgba(245, 222, 179, 0.9);
        }

        .feature-box h4 {
            font-size: 1.5rem;
            margin-bottom: 10px;
            color: #5d4037;
        }

        .feature-box p {
            font-size: 1rem;
            color: #5d4037;
        }

        .footer {
            text-align: center;
            padding: 20px 0;
            background: rgba(245, 222, 179, 0.8);
            color: #5d4037;
            margin-top: 50px;
            backdrop-filter: blur(8px);
            box-shadow: 0 -2px 5px rgba(0,0,0,0.1);
        }

    </style>
</head>
<body>

    <!-- Side Navigation -->
    <div class="sidenav">
        <h2>TeaToYou</h2>
        <a href="homepage.php">Home</a>
        <a href="menu.php">Menu</a>
        <a href="cart.php">Cart</a>
        <a href="about.php">About Us</a>
        <a href="contact.php">Contact</a>
        <a href="login.php">Log In</a>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="glass-card">
            <h1>Welcome to TeaToYou!</h1>
            <p>Sweetness and comfort in every sip. Fresh milk teas, delivered just for you!</p>
            <a href="menu.php" class="button-primary">Explore Our Menu</a>
        </div>

        <section class="features">
            <div class="feature-box">
                <h4>Freshly Brewed</h4>
                <p>Premium tea leaves, fresh daily for ultimate flavor.</p>
            </div>
            <div class="feature-box">
                <h4>Fast Delivery</h4>
                <p>Get your favorite drinks in less than 30 minutes!</p>
            </div>
            <div class="feature-box">
                <h4>Customize Your Cup</h4>
                <p>Choose toppings, sugar levels, and unique flavors.</p>
            </div>
            <div class="feature-box">
                <h4>Eco-Friendly</h4>
                <p>Reusable cups and sustainable materials, because we care.</p>
            </div>
        </section>
    </div>

    <!-- Footer -->
    <div class="footer">
        <p>&copy; 2025 TeaToYou. Wok'd with Love, Served for Juan. 🧋</p>
    </div>

</body>
</html>
