class Person {
    constructor(title, author, publication , price) {
        this.title = title;
        this.author = author;
        this.publication = publication;
        this.price= price;
        
    }

    displayDetails()  {
        console.log(`title: ${this.name}`);
        console.log(`Author: ${this.age}`);
        console.log(`Country: ${this.country}`);
        console.log(`Birthplace: ${this.birthplace}`);

    }
}

