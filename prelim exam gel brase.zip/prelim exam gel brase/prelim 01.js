<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Form</title>
</head>
<body>
    <h1>Submit Booking</h1>
    <form action="submit_booking.php" method="POST">
        <!-- Name Input -->
        <label for="name">Name:</label><br>
        <input type="text" id="name" name="name" required><br>

        <!-- Phone Input -->
        <label for="phone">Phone:</label><br>
        <input type="tel" id="phone" name="phone" required><br>

        <!-- Email Input -->
        <label for="email">Email:</label><br>
        <input type="email" id="email" name="email" required><br><br>

        <!-- TAXI Selection -->
        <label for="taxi">Which TAXI do you require?</label><br>
        <input type="radio" id="grab" name="ta" value="Grab">
        <label for="grab">Grab</label><br>
        <input type="radio" id="uber" name="ta" value="Uber">
        <label for="uber">Uber</label><br>
        <input type="radio" id="angkas" name="ta" value="Angkas">
        <label for="angkas">Angkas</label><br>

        <!-- Extras Section -->
        <label>Extras:</label><br>
        <input type="checkbox" id="babySeat" name="extras" value="Baby Seat">
        <label for="babySeat">Baby Seat</label><br>
        <input type="checkbox" id="wheelchair" name="extras" value="Wheelchair Access">
        <label for="wheelchair">Wheelchair Access</label><br>
        <input type="checkbox" id="dogSeater" name="extras" value="Dog Seater">
        <label for="dogSeater">Dog Seater</label><br>

        <!-- Pickup Date/Time -->
        <label for="pickupDateTime">Pickup Date/Time:</label><br>
        <input type="datetime-local" id="pickupDateTime" name="pickupDateTime" required><br><br>

        <!-- Pickup Place -->
        <label for="pickupPlace">Pickup Place:</label><br>
        <select id="pickupPlace" name="pickupPlace">
            <option value="Taxi Office">Taxi Office</option>
            <option value="Town Hall">Town Hall</option>
            <option value="I pass HTML Exam">I pass HTML Exam</option>
        </select><br>

        <!-- Dropoff Place -->
        <label for="dropoffPlace">Dropoff Place:</label><br>
        <input type="text" id="dropoffPlace" name="dropoffPlace" required><br><br>

        <!-- Special Instructions -->
        <label for="specialInstructions">Special Instructions:</label><br>
        <textarea id="specialInstructions" name="specialInstructions" rows="4" cols="50"></textarea><br><br>

        <!-- Submit Button -->
        <input type="submit" value="Submit Booking">
    </form>
</body>
</html>
