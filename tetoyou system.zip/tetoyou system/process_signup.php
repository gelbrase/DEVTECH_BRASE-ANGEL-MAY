<?php
// Include the database connection
require_once "db_connect.php";

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST["name"]);
    $email = trim($_POST["email"]);
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT); // Hash password

    // Check if email already exists
    $checkEmail = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $checkEmail->bind_param("s", $email);
    $checkEmail->execute();
    $checkEmail->store_result();

    if ($checkEmail->num_rows > 0) {
        echo "<script>alert('Email already registered! Please login.'); window.location='signup.php';</script>";
    } else {
        // Insert new user into database
        $stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $name, $email, $password);

        if ($stmt->execute()) {
            echo "<script>alert('Sign up successful! You can now login.'); window.location='login.php';</script>";
        } else {
            echo "<script>alert('Error in sign up. Please try again.'); window.location='signup.php';</script>";
        }

        $stmt->close();
    }

    $checkEmail->close();
    $conn->close();
} else {
    header("Location: process_login.php");
    exit();
}
?>
