<?php
// Start the session if needed (useful for things like cart management, user authentication)
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu</title>
    
    <!-- Bootstrap CSS for easy styling -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS for Milk Tea Theme -->
    <style>
        /* Ensure the body takes full height */
        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5dc; /* Beige background */
            color: #5d4037; /* Dark brown text for contrast */
            display: flex;
            flex-direction: column;
            justify-content: space-between; /* Push footer to the bottom */
        }

        /* Side navigation bar */
        .sidenav {
            height: 100%;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #d8c8b8; /* Soft beige for sidebar */
            padding-top: 20px;
            padding-left: 20px;
        }

        .sidenav a {
            display: block;
            color: #5d4037; /* Dark brown text for links */
            font-size: 1.2rem;
            text-decoration: none;
            margin: 10px 0;
        }

        .sidenav a:hover {
            color: #ff7f50; /* Highlight color on hover */
        }

        /* Main content area */
        .main-content {
            margin-left: 250px;
            padding: 20px;
            flex: 1; /* Allow main content to expand and push the footer down */
            
        }

        .navbar {
            background-color: #d8c8b8; /* Beige background for navbar */
        }

        .navbar-brand {
            font-size: 1.8rem;
            color: #5d4037;
        }

        .hero-section {
            text-align: center;
            padding: 150px 0;
            background-color: rgba(0, 0, 0, 0.1); /* Light overlay for contrast */
           
        }

        .hero-section h1 {
            font-size: 3rem;
            margin-bottom: 10px;
        }

        .hero-section p {
            font-size: 1.2rem;
            margin-bottom: 30px;
        }

        .button-primary {
            background-color: #ffebcd; /* Light cream button */
            color: #5d4037; /* Dark brown text */
            font-size: 1.1rem;
            padding: 10px 30px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }

        .button-primary:hover {
            background-color: #5d4037; /* Highlight color for button on hover */
            color: #fff;
        }

        .footer {
            text-align: center;
            padding: 20px 0;
            background-color: #d8c8b8; /* Same beige footer background */
            color: #5d4037;
        }
    </style>
</head>
<body >

    <!-- Side Navigation -->
    <div class="sidenav">
        <h2>TeaToYou</h2>
        <a href="homepage.php">Home</a>
        <a href="menu.php">Menu</a>
        <a href="cart.php">Cart</a>
        <a href="about.php">About Us</a>
        <a href="contact.php">Contact</a>
        <a href="login.php">Log In</a>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        
        <!-- Hero Section -->
        <section class="hero-section">
            <div class="container">
                <h1>Welcome to TeaToYou!</h1>
                <p>Your favorite milk tea, delivered fresh to your door.</p>
                <a href="menu.php" class="button-primary">Explore Our Menu</a>
            </div>
        </section>

    </div>

    <!-- Footer -->
    <div class="footer">
        <p>&copy; 2025 TeaToYou. All rights reserved.</p>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
