<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f5f5dc;
            color: #5d4037;
            font-family: 'Arial', sans-serif;
        }
        .container {
            margin-top: 50px;
        }
        .cart-item {
            padding: 15px;
            border-bottom: 1px solid #ccc;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .button-remove {
            background-color: #ff4d4d;
            color: white;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
            border-radius: 5px;
        }
        .button-remove:hover {
            background-color: #cc0000;
        }
        .checkout-btn {
            background-color: #28a745;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            display: none; /* Hide initially */
        }
        .empty-cart {
            text-align: center;
            font-size: 18px;
            color: #888;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="text-center">Your Cart</h1>
        <div id="cart-items"></div>
        <h3 class="text-right">Total: ₱<span id="cart-total">0</span></h3>
        <button class="checkout-btn" id="checkout-btn" onclick="checkout()">Proceed to Checkout</button>
    </div>

    <script>
        function loadCart() {
            let cart = localStorage.getItem("cart") ? JSON.parse(localStorage.getItem("cart")) : [];
            let cartItems = document.getElementById("cart-items");
            let total = 0;
            cartItems.innerHTML = "";

            if (cart.length === 0) {
                cartItems.innerHTML = "<p class='empty-cart'>Your cart is empty.</p>";
                document.getElementById("checkout-btn").style.display = "none";
                return;
            }

            cart.forEach((item, index) => {
                total += parseFloat(item.price);
                cartItems.innerHTML += `
                    <div class='cart-item'>
                        <span>${item.name} - ₱${item.price.toFixed(2)}</span>
                        <button class='button-remove' onclick='removeFromCart(${index})'>Remove</button>
                    </div>`;
            });

            document.getElementById("cart-total").innerText = total.toFixed(2);
            document.getElementById("checkout-btn").style.display = "block";
        }
        
        function removeFromCart(index) {
            let cart = JSON.parse(localStorage.getItem("cart"));
            cart.splice(index, 1);
            localStorage.setItem("cart", JSON.stringify(cart));
            loadCart();
        }
        
        function checkout() {
            if (confirm("Are you sure you want to proceed to checkout?")) {
                alert("Thank you for your purchase!");
                localStorage.removeItem("cart");
                loadCart();
            }
        }
        
        window.onload = loadCart;
    </script>
</body>
</html>
