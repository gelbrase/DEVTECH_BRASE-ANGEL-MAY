<?php
$host = "localhost"; // Change if using a remote database
$dbname = "teatoyou"; // Database name
$username = "root"; // Default username in XAMPP
$password = ""; // Default password in XAMPP (leave empty)

// Create database connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
