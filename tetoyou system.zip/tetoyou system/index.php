<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to TeaToYou</title>
    <style>
        /* Global Styles */
        body {
            font-family: 'Georgia', serif;
            font-size: 15px;
            text-align: center;
            margin: 0;
            background-color: #F5E8D7; /* Beige, inspired by milk tea */
            background-image: url('https://www.transparenttextures.com/patterns/food.png'); /* Adds texture */
            color: #5A3931; /* Dark brown text */
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            min-height: 100vh;
        }

        /* Header Section */
        h1 {
            font-size: 3em;
            color: #4A3221; /* Rich brown */
            margin-bottom: 15px;
        }

        p {
            font-size: 1.5em;
            color: #6E4F39; /* Light brown */
            margin-bottom: 40px;
        }

        /* Welcome Box */
        .welcome-box {
            margin: auto;
            padding: 30px;
            width: 80%;
            max-width: 600px;
            background-color: #FFFFFF; /* White background for contrast */
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        /* Button Styles */
        .btn {
            padding: 15px 30px;
            margin: 10px;
            font-size: 1.2em;
            font-weight: bold;
            color: #FFFFFF;
            background-color: #C29872; /* Milk tea beige tone */
            text-decoration: none;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            transition: all 0.3s ease-in-out;
        }

        .btn:hover {
            background-color: #D4B89F; /* Slightly lighter beige */
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        }

        /* Footer */
        footer {
            background-color: #C29872;
            color: #FFFFFF;
            padding: 10px;
            text-align: center;
            font-size: 0.9em;
        }
    </style>
</head>
<body>
    <!-- Welcome Box -->
    <div class="welcome-box">
        <h1>Welcome to TeaToYou Online Milk Tea Delivery</h1>
        <p>Your one-stop destination for delicious milk tea delivered to your doorstep!</p>
        <a href="signup.php" class="btn">Sign Up</a>
        <a href="login.php" class="btn">Login</a>
    </div>

    <!-- Footer Section -->
    <footer>
        &copy; 2025 TeaToYou. All rights reserved. Designed for milk tea enthusiasts.
    </footer>
</body>
</html>
