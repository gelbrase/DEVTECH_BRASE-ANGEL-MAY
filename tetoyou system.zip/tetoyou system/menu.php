<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Custom CSS -->
    <style>
        body {
            background-color: #f5f5dc; /* Beige background */
            color: #5d4037;
            font-family: 'Arial', sans-serif;
            
        }

        .sidenav {
            height: 100%;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #d8c8b8;
            padding-top: 20px;
            padding-left: 20px;
            
        }

        .sidenav a {
            display: block;
            color: #5d4037;
            font-size: 1.2rem;
            text-decoration: none;
            margin: 10px 0;
            
        }

        .sidenav a:hover {
            color: #ff7f50;
        }

        .main-content {
            margin-left: 250px;
            padding: 20px;
        }

        .menu-category {
            width: 80%;
            margin: auto;
            margin-bottom: 30px;
            text-align: center;
        }

        .drink-item {
            display: inline-block;
            width: 200px;
            background: #ffebcd;
            padding: 15px;
            margin: 10px;
            border-radius: 10px;
            box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .drink-item span {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
        }

        .button-cart {
            background-color: #ff7f50;
            color: white;
            border: none;
            padding: 8px 12px;
            cursor: pointer;
            border-radius: 5px;
            
        }

        .button-cart:hover {
            background-color: #d2691e;
        }

        .footer {
            text-align: center;
            padding: 20px;
            background-color: #d8c8b8;
            color: #5d4037;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    
    <!-- Side Navigation -->
    <div class="sidenav">
        <h2>TeaToYou</h2>
        <a href="homepage.php">Home</a>
        <a href="menu.php">Menu</a>
        <a href="cart.php">Cart</a>
        <a href="about.php">About Us</a>
        <a href="contact.php">Contact</a>
        <a href="login.php">Log In</a>
    </div>
    
    <!-- Main Content -->
    <div class="main-content">
        
        

    <div class="drink-item">
    <img src="https://via.placeholder.com/100" alt="Okinawa">
    <span>Okinawa</span><span>₱60</span>
    <button class="button-cart" onclick="addToCart('Okinawa', 60)">Add to Cart</button>
</div>

<div class="drink-item">
    <img src="img/taro_96.png" alt="Taro">
    <span>Taro</span><span>₱75</span>
    <button class="button-cart" onclick="addToCart('Taro', 75)">Add to Cart</button>
</div>

<div class="drink-item">
    <img src="https://via.placeholder.com/100" alt="Wintermelon">
    <span>Wintermelon</span><span>₱60</span>
    <button class="button-cart" onclick="addToCart('Wintermelon', 60)">Add to Cart</button>
</div>

<div class="drink-item">
    <img src="https://via.placeholder.com/100" alt="Cookies and Cream">
    <span>Cookies and Cream</span><span>₱60</span>
    <button class="button-cart" onclick="addToCart('Cookies and Cream', 60)">Add to Cart</button>
</div>

<div class="drink-item">
    <img src="https://via.placeholder.com/100" alt="Mango Cheesecake">
    <span>Mango Cheesecake</span><span>₱75</span>
    <button class="button-cart" onclick="addToCart('Mango Cheesecake', 75)">Add to Cart</button>
</div>

<div class="drink-item">
    <img src="https://via.placeholder.com/100" alt="Matcha">
    <span>Matcha</span><span>₱65</span>
    <button class="button-cart" onclick="addToCart('Matcha', 65)">Add to Cart</button>
</div>

<div class="drink-item">
    <img src="https://via.placeholder.com/100" alt="Red Velvet">
    <span>Red Velvet</span><span>₱70</span>
    <button class="button-cart" onclick="addToCart('Red Velvet', 70)">Add to Cart</button>
</div>

<div class="drink-item">
    <img src="https://via.placeholder.com/100" alt="Dark Choco">
    <span>Dark Choco</span><span>₱60</span>
    <button class="button-cart" onclick="addToCart('Dark Choco', 60)">Add to Cart</button>
</div>

<div class="drink-item">
    <img src="https://via.placeholder.com/100" alt="Hazelnut">
    <span>Hazelnut</span><span>₱70</span>
    <button class="button-cart" onclick="addToCart('Hazelnut', 70)">Add to Cart</button>
</div>

<div class="drink-item">
    <img src="https://via.placeholder.com/100" alt="Vanilla">
    <span>Vanilla</span><span>₱70</span>
    <button class="button-cart" onclick="addToCart('Vanilla', 70)">Add to Cart</button>
</div>

<div class="drink-item">
    <img src="https://via.placeholder.com/100" alt="Avocado">
    <span>Avocado</span><span>₱70</span>
    <button class="button-cart" onclick="addToCart('Avocado', 70)">Add to Cart</button>
</div>

<div class="drink-item">
    <img src="https://via.placeholder.com/100" alt="Hokkaido">
    <span>Hokkaido</span><span>₱70</span>
    <button class="button-cart" onclick="addToCart('Hokkaido', 70)">Add to Cart</button>
</div>



<script>
    function addToCart(name, price) {
        let cart = localStorage.getItem("cart") ? JSON.parse(localStorage.getItem("cart")) : [];
        cart.push({ name: name, price: parseFloat(price) });
        localStorage.setItem("cart", JSON.stringify(cart));
        alert(name + " has been added to your cart!");
    }
</script>

        </div>

        <h2 class="text-center">FRUIT TEA</h2>
        <div class="menu-category">
            <div class="drink-item"><span>Strawberry</span><span>₱60</span><button class="button-cart">Add to Cart</button></div>
            <div class="drink-item"><span>Blueberry</span><span>₱75</span><button class="button-cart">Add to Cart</button></div>
            <div class="drink-item"><span>Green Apple</span><span>₱60</span><button class="button-cart">Add to Cart</button></div>
            <div class="drink-item"><span>Passion Fruit</span><span>₱60</span><button class="button-cart">Add to Cart</button></div>
            <div class="drink-item"><span>Peach</span><span>₱75</span><button class="button-cart">Add to Cart</button></div>
            <div class="drink-item"><span>Lemon</span><span>₱65</span><button class="button-cart">Add to Cart</button></div>
            <div class="drink-item"><span>Watermelon</span><span>₱70</span><button class="button-cart">Add to Cart</button></div>
            <div class="drink-item"><span>Grapes</span><span>₱60</span><button class="button-cart">Add to Cart</button></div>
        </div>
            
            <h3 class="text-center">SPECIALTY DRINKS</h3>
        <div class="menu-category">
            <div class="drink-item"><span>Oreo Chesscake</span><span>₱120/span><button class="button-cart">Add to Cart</button></div>
            <div class="drink-item"><span>Choco Straberry</span><span>₱135</span><button class="button-cart">Add to Cart</button></div>
            <div class="drink-item"><span>Dirty Matcha</span><span>₱130</span><button class="button-cart">Add to Cart</button></div>
            <div class="drink-item"><span>Mango Chesscake</span><span>₱110</span><button class="button-cart">Add to Cart</button></div>
            <div class="drink-item"><span>Java Chip</span><span>₱115</span><button class="button-cart">Add to Cart</button></div>
            <div class="drink-item"><span>Red Velvet Cream Chess</span><span>₱120</span><button class="button-cart">Add to Cart</button></div>
            <div class="drink-item"><span>Mint Chocolate Cream</span><span>₱100</span><button class="button-cart">Add to Cart</button></div>
            <div class="drink-item"><span>Salted Caramel</span><span>₱110</span><button class="button-cart">Add to Cart</button></div>
            
    </div>
    
    <!-- Footer -->
    <div class="footer">
        <p>&copy; 2025 TeaToYou. All rights reserved.</p>
    </div>

    <!-- JavaScript to handle Add to Cart functionality -->
    <script>
        function addToCart(name, price) {
            let cart = localStorage.getItem("cart") ? JSON.parse(localStorage.getItem("cart")) : [];
            cart.push({ name: name, price: price });
            localStorage.setItem("cart", JSON.stringify(cart));
            alert(name + " added to cart!");
        }
    </script>
</body>
</html>
