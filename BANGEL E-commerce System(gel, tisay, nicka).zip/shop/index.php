<?php
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = htmlspecialchars($_POST['username']);
    $password = $_POST['password'];

    try {
        // Prepare and execute the query to fetch the user
        $stmt = $conn->prepare("SELECT * FROM users WHERE username = :username");
        $stmt->bindParam(':username', $username);
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        

        
        // Check if the username exists
        if (!$user) {
            $error_message = "Username not found. Please sign up to create an account.";
        } elseif (password_verify($password, $user['password'])) {
            // If the username exists and the password matches
            echo "Login successful! Welcome, " . htmlspecialchars($user['username']);
            // Redirect to another page, e.g., the home page after successful login
            header("Location: index.html");
            exit; // Ensure no further script execution
        } else {
            // If the password is incorrect
            $error_message = "Invalid password. Please try again.";
        }
    } catch (PDOException $e) {
        $error_message = "An error occurred: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: black;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 500px;
            margin: 0;
        }
        .login-container {
            background: transparent;
            padding: 20px 30px;
            border-radius: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 700px;
            text-align: center;
        }
        h1 {
            margin-bottom: 20px;
            color: pink;
            width: 100%;
            max-width: 100vp;
            font-size: 90px;
            font-weight: 70;
            font-style: italic;
        }
        
        label {
            display: block;
            margin: 10px 0 5px;
            color: #555;
            text-align: left;
        }
        input {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            background: pink;
            color: #fff;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
        }
        button:hover {
            background: fuchsia;
        }
        .error {
            color: red;
            margin-bottom: 15px;
        }
        p {
            color: pink;
            margin-bottom: 15px;
        }
        a {
            color: fuchsia;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h1>WELCOME TO BANGEL SHOP!</h1>
        <?php if (!empty($error_message)): ?>
            <div class="error"><?= htmlspecialchars($error_message) ?></div>
        <?php endif; ?>
        <form method="POST">
            <label for="username">Username</label>
            <input type="text" id="username" name="username" required>

            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>

            <button type="submit">Login</button>
        </form>
        <p>Don't have an account? <a href="signup.php">Sign Up</a></p>
    </div>
</body>
</html>
