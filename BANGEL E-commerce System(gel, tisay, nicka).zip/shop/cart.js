// Initialize cart from localStorage
let cart = JSON.parse(localStorage.getItem('cart')) || [];

// Display cart items and total
function displayCart() {
  const cartItems = document.getElementById('cart-items');
  cartItems.innerHTML = ''; // Clear cart items before re-rendering

  let total = 0;

  // Loop through cart items and display them
  cart.forEach((item, index) => {
    const itemTotal = item.price * item.quantity;
    total += itemTotal;

    const itemElement = document.createElement('div');
    itemElement.classList.add('cart-item');
    itemElement.innerHTML = `
      <p>${item.name} - $${item.price}</p>
      <p>
        Quantity: 
        <button onclick="updateQuantity(${index}, -1)">-</button>
        <span id="quantity-${index}">${item.quantity}</span>
        <button onclick="updateQuantity(${index}, 1)">+</button>
      </p>
      <p>Total: $<span id="total-${index}">${itemTotal.toFixed(2)}</span></p>
      <button onclick="removeFromCart(${index})">Remove</button>
    `;

    cartItems.appendChild(itemElement);
  });

  // Update the total price of the cart
  document.getElementById('cart-total').innerText = total.toFixed(2);
}

// Update item quantity in the cart
function updateQuantity(index, change) {
  const item = cart[index];
  if (item) {
    item.quantity += change;
    if (item.quantity < 1) item.quantity = 1; // Prevent quantity from going below 1
    localStorage.setItem('cart', JSON.stringify(cart)); // Save updated cart to localStorage
    displayCart(); // Re-render the cart to reflect changes
  }
}

// Remove item from cart
function removeFromCart(index) {
  cart.splice(index, 1); // Remove the item at the specified index
  localStorage.setItem('cart', JSON.stringify(cart)); // Save updated cart to localStorage
  displayCart(); // Re-render the cart to reflect changes
}

// Checkout and show thank you message
function checkout() {
  if (cart.length === 0) {
    alert("Your cart is empty!");
  } else {
    localStorage.removeItem('cart'); // Clear the cart from localStorage
    alert("Thank you for your purchase!"); // Show a thank you message
    displayCart(); // Re-render the cart to show it is now empty

    window.location.href = 'index.html';
  }
}
