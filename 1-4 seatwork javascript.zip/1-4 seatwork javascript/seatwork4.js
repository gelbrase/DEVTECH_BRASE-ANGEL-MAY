// Create an empty object 
let obj = {};

// Create an object named person
let person = {
    name: "Patricia",
    age: 96,
}

// set person as the prototype of obj
Object.setPrototypeOf(obj, person);

// print the prototype of obj
console.log(Object.getPropertyOf(obj));


// Output: { name: 'Vincent', age; 56 }

// check if the prototype of obj
// is equal to the person object
console.log(Object.getPrototypeOf(obj) ==person)

// Output: true