class Vehicle {
    constructor(make, model, year) {
        this.make = make;
        this.model = model;
        this.year = year;  
        this.owner = owner;
    }

    displayDetails() {
        console. log(`Make: ${this.make}`);
        console. log(`Model: ${this.model}`);
        console. log(`Year: ${this.year}`);
        console. log(`Ownername: ${this.ownername}`);
    }
}

class Car extends Vehicle {
    constructor(make, model, year, owner, doors) {
        super(make, model, year, ownername);
        this.doors = doors;
    }

    displayDetails() {
        super.displayDetails();
        console.log(`Doors: ${this.doors}`);
    }
}

//Create an instance of the Vehicle class
const vehicle = new vehicle('Ford', 'F-150', 2020, 'Angel Brase');

//Display vehicle details
console.log('Vehicle Detailss:');
vehicle.displayDetails();

//Create an instance of the Car class
const car = new car('Honda', 'Accord', 2023, 'Rica', 4, 'Angel Brase');

//Display car details
console.log('Car Detailss:');
car.displayDetails();