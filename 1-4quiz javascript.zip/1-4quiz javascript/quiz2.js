let num1 = 21;
let num2 = 19;
if (num1 > num2) {
    console.log("num1 is greater.");
} else { 
    console.log("num2 is greater.");
}

// brase angel may
//T2023-0095