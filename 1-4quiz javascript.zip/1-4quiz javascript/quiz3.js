
    let num = -3;
    if (num > 0) {
        console.log(num + "is positive.");
    } else if (num < 0) {
        console.log(num + "is negative."); 
    }
