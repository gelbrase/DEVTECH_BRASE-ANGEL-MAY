let num = 1;
if (num % 2== 0) {
    console.log("The number is odd.");
    
    } else{
    console.log("The number is even.");
}

// brase angel may
//T2023-0095